require File.dirname(__FILE__) + '/test_helper.rb'

class CacheAdvanceTest < Test::Unit::TestCase
end
